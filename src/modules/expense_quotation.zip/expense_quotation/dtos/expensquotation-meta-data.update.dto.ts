/* eslint-disable prettier/prettier */
import { CreateExpensQuotationMetaDataDto } from './expensquotation-meta-data.create.dto';

export class UpdateExpensQuotationMetaDataDto extends CreateExpensQuotationMetaDataDto {}
