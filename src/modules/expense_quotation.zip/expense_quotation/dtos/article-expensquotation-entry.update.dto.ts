/* eslint-disable prettier/prettier */
import { ApiProperty } from '@nestjs/swagger';
import { CreateArticleExpensQuotationEntryDto } from './article-expensquotation-entry.create.dto';

export class UpdateArticleExpensQuotationEntryDto extends CreateArticleExpensQuotationEntryDto {

   
}
