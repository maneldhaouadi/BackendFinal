/* eslint-disable prettier/prettier */
export enum EXPENSQUOTATION_STATUS {
  Expired = 'expired',
  Draft = 'draft',
}