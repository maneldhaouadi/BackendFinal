import { CreateArticleInvoiceEntryDto } from "src/modules/invoice/dtos/article-invoice-entry.create.dto";

export class ExpenseUpdateArticleInvoiceEntryDto extends CreateArticleInvoiceEntryDto {}
