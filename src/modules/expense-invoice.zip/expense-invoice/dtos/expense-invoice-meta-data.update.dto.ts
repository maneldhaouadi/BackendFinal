import { ExpenseCreateInvoiceMetaDataDto } from "./expense-invoice-meta-data.create.dtos";

export class ExpenseUpdateInvoiceMetaDataDto extends ExpenseCreateInvoiceMetaDataDto {}
